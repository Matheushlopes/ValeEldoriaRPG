from typing import Annotated
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from app.services import accounts, characters

router = APIRouter(prefix='/api')

class Credentials(BaseModel):
    username: str
    password: str

class NewCharacter(BaseModel):
    name: str
    class_id: str


def current_user(authorization: Annotated[str | None, Header()] = None):
    token = (authorization or '').removeprefix('Bearer ').strip()
    return accounts.authenticated_user(token)

@router.post('/register')
def register(data: Credentials):
    return accounts.register(data.username, data.password)

@router.post('/login')
def login(data: Credentials):
    return accounts.login(data.username, data.password)

@router.get('/me')
def me(user=Depends(current_user)):
    return {'user': user, 'character': characters.get_character(user['id'])}

@router.post('/characters', status_code=201)
def create(data: NewCharacter, user=Depends(current_user)):
    return characters.create_character(user['id'], data.name, data.class_id)

@router.post('/logout')
def logout(authorization: Annotated[str | None, Header()] = None):
    accounts.logout((authorization or '').removeprefix('Bearer ').strip())
    return {'ok': True}
