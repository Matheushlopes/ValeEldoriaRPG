/* Rede e autenticação: isoladas da lógica de combate do protótipo. */
'use strict';
const Online = (() => {
  const TOKEN_KEY = 'eldoria_online_token';
  let token = sessionStorage.getItem(TOKEN_KEY);
  let socket = null;
  let selfId = null;
  let peers = [];
  let serverMonsters = false;
  let lastSent = 0;
  let reconnectTimer = null;
  let shouldReconnect = true;
  const $online = id => document.getElementById(id);

  function status(message) { $online('online-status').textContent = message; }
  async function request(path, options = {}) {
    const headers = {'Content-Type':'application/json'};
    if (token) headers.Authorization = `Bearer ${token}`;
    const response = await fetch('/api' + path, {...options, headers});
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Error(typeof data.detail === 'string' ? data.detail : 'Erro na requisição');
    return data;
  }
  function showAuth() {
    adventureStarted = false;
    $online('online-gate').classList.remove('hidden');
    $online('online-account').classList.remove('hidden');
    $online('character-creation').classList.add('hidden');
  }
  function showCreation() {
    $online('online-gate').classList.add('hidden');
    $online('character-creation').classList.remove('hidden');
  }
  function applyCharacter(character) {
    const choice = GAME_RULES.starters[character.class_id];
    Object.assign(hero, {
      name:character.name, classId:character.class_id, className:choice.label,
      level:character.level, xp:character.xp, gold:character.gold,
      str:character.str, int:character.int, dex:character.dex, con:character.con,
      points:character.points
    });
    player.x = character.x;
    player.y = character.y;
    // Equipamento inicial segue o mesmo construtor do jogo offline anterior.
    const w = choice.weapon;
    equipment.weapon = makeStarter(w.name,'weapon',w.stat,w.base,w.iconSrc,w.weaponKind);
    for (const [slot,name,value,icon] of [
      ['helmet','Capuz de Couro do Novato',1,'icons/item-040.svg'],
      ['armor','Colete de Couro do Novato',2,'icons/item-060.svg'],
      ['gloves','Luvas de Couro do Novato',1,'icons/item-080.svg'],
      ['boots','Botas de Couro do Novato',1,'icons/item-100.svg'],
      ['ring','Anel do Primeiro Passo',1,'icons/item-120.svg'],
      ['amulet','Colar da Primeira Jornada',1,'icons/item-140.svg']
    ]) equipment[slot] = makeStarter(name,slot,'defense',value,icon);
    recalcHero();
    hero.hp = Math.min(hero.maxHp, character.hp > 0 ? character.hp : hero.maxHp);
    hero.mp = Math.min(hero.maxMp, character.mp > 0 ? character.mp : hero.maxMp);
    $online('hero-name').textContent = character.name;
    $online('character-creation').classList.add('hidden');
    $online('online-gate').classList.add('hidden');
    adventureStarted = true;
    last = performance.now(); lastPaint = 0;
    keys.clear(); updateHud(); renderCharacter(); renderInventory();
    status('Conectando…');
    connect();
  }
  async function initialize() {
    if (!token) return showAuth();
    try {
      const data = await request('/me');
      if (data.character) applyCharacter(data.character);
      else showCreation();
    } catch (_) {
      token = null; sessionStorage.removeItem(TOKEN_KEY); showAuth();
    }
  }
  async function submitAuth(event) {
    event.preventDefault();
    const action = event.submitter?.value || 'login';
    const username = $online('online-username').value;
    const password = $online('online-password').value;
    try {
      const result = await request('/' + action, {method:'POST', body:JSON.stringify({username,password})});
      token = result.token; sessionStorage.setItem(TOKEN_KEY,token);
      $online('online-password').value = '';
      const me = await request('/me');
      if (me.character) applyCharacter(me.character);
      else showCreation();
    } catch (error) { $online('online-error').textContent = error.message; }
  }
  async function createCharacter(name, classId) {
    try {
      const character = await request('/characters', {
        method:'POST', body:JSON.stringify({name,class_id:classId})
      });
      applyCharacter(character);
    } catch (error) { $online('creation-error').textContent = error.message; }
  }
  function connect() {
    if (!token || !shouldReconnect) return;
    if (socket && (socket.readyState === WebSocket.CONNECTING || socket.readyState === WebSocket.OPEN)) return;
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    socket = new WebSocket(`${protocol}//${location.host}/ws`);
    socket.addEventListener('open', () => socket.send(JSON.stringify({type:'auth',token})));
    socket.addEventListener('message', event => {
      const message = JSON.parse(event.data);
      if (message.type === 'welcome') selfId = message.self;
      if (message.monsters) syncMonsters(message.monsters);
      if (message.type === 'mob_hit') {
        const mob=monsters.find(m=>m.id===message.mob_id);
        if(mob){mob.hp=message.hp;mob.defeated=message.hp<=0;floatText(message.x,message.y-25,`-${message.hit}`,'#ffe0a0');}
        if(message.kill && message.killer===selfId) show('⚔️ KS! Você finalizou o monstro.');
      }
      if (message.type === 'reward') {
        hero.xp=message.xp;hero.gold=message.gold;hero.level=message.level;hero.points=message.points;
        floatText(player.x,player.y-34,`+${message.gained_xp} XP · +${message.gained_gold} ouro`,'#f7d777');
        recalcHero();updateHud();renderCharacter();
      }
      if (message.type === 'players' || message.type === 'welcome') {
        peers = message.players.filter(p => p.id !== selfId);
        status(`🟢 Online · ${message.players.length} jogador(es)`);
      }
    });
    socket.addEventListener('close', event => {
      peers = [];
      status('🔴 Desconectado · reconectando…');
      if ([4001,4003].includes(event.code)) { shouldReconnect=false; showAuth(); return; }
      if (shouldReconnect) reconnectTimer = setTimeout(connect, 2500);
    });
  }
  function syncMonsters(list) {
    serverMonsters=true;
    const existing=new Map(monsters.map(m=>[m.id,m]));
    const updated=[];
    for(const data of list){
      let mob=existing.get(data.id);
      if(!mob){
        mob={...data,phase:data.id*1.7,spawnX:data.x,spawnY:data.y,
             baseLevel:data.level,aggro:false,nextHit:0,respawnAt:0};
      }
      Object.assign(mob,data);
      updated.push(mob);
    }
    monsters.splice(0,monsters.length,...updated);
  }
  function attack(mob,magic=false) {
    if(!serverMonsters || !socket || socket.readyState!==WebSocket.OPEN)return;
    socket.send(JSON.stringify({type:'attack',mob_id:mob.id,magic}));
  }
  function shared(){return serverMonsters;}
  function tick(now) {
    if (!adventureStarted || !socket || socket.readyState !== WebSocket.OPEN) return;
    if (now-lastSent < 100) return;
    lastSent=now;
    socket.send(JSON.stringify({type:'move',x:player.x,y:player.y,face:player.face}));
  }
  function draw(ctx, visible) {
    for (const p of peers) {
      if (!visible(p.x,p.y)) continue;
      ctx.save();
      ctx.fillStyle = p.class_id === 'warrior' ? '#d9a25e' : p.class_id === 'archer' ? '#7cdb8b' : '#a8a0f2';
      ctx.beginPath();ctx.arc(p.x,p.y,11,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle='#f9e4ae';ctx.lineWidth=2;ctx.stroke();
      ctx.font='bold 12px sans-serif';ctx.textAlign='center';ctx.fillStyle='#fff3d6';
      ctx.fillText(p.name+' · Nv '+p.level,p.x,p.y-23);
      ctx.restore();
    }
  }
  function logout() {
    shouldReconnect=false;
    if (reconnectTimer) clearTimeout(reconnectTimer);
    if (socket) socket.close();
    request('/logout',{method:'POST'}).catch(()=>{}).finally(()=>{
      sessionStorage.removeItem(TOKEN_KEY);
      location.reload();
    });
  }
  document.addEventListener('DOMContentLoaded', () => {
    $online('online-auth-form').addEventListener('submit', submitAuth);
    $online('online-logout').addEventListener('click', logout);
    initialize();
  });
  return {createCharacter,tick,draw,attack,shared};
})();
